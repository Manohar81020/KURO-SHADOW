<?php

$servername = "mysql-shadowxmod.alwaysdata.net";
$username = "shadowxmod_ff";
$password = "FREEFIRE@123";
$dbname = "shadowxmod_ff";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Database Connection Error: " . mysqli_connect_error());
}
  
?>